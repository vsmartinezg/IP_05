﻿using System.Linq.Expressions;
using System.Timers;

class program
{
    static void Main(string[] args)
    {
        //EJERCICIO 1
        int num;

        Console.WriteLine("Ejecicio 1");
        Console.WriteLine("Por favor ingresa un número ENTERO");
        num = int.Parse(Console.ReadLine());

        if (num < 0)
        {
            Console.WriteLine("El número es un entero negativo :(");
        }
        else if (num > 0 )
        {
            Console.WriteLine("El número es un entero positivo :D");
        }
        else 
        {
            Console.WriteLine("El número es 0");
        }
        Console.ReadKey();

        //EJERCICIO 2
        int num2;

        Console.WriteLine();
        Console.WriteLine("Ejercicio 2: Días de la semana");
        Console.WriteLine("Ingrese un número ENTRE 1 y 7");
        num2 = int.Parse(Console.ReadLine());

            switch (num2)
            {
                case 1:
                    Console.WriteLine("El día es lunes");
                    break;

                case 2:
                    Console.WriteLine("El día es martes)");
                    break;

                case 3:
                    Console.WriteLine("El día es miercoles");
                    break;

                case 4:
                    Console.WriteLine("El día es jueves");
                    break;

                case 5:
                    Console.WriteLine("El día es viernes :D");
                    break;

                case 6:
                    Console.WriteLine("El día es sábado :D");
                    break;

                case 7:
                    Console.WriteLine("El día es domingo");
                    break;

                default:
                    Console.WriteLine("ERROR: El número a ingresar debe estar contenido entre 1 y 7");
                    break;
            }
        Console.WriteLine( );
        Console.WriteLine("Gracias por venir!");

        }

}
