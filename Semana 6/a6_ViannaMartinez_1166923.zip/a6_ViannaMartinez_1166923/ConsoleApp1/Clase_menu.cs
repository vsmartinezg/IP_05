﻿using System.Linq.Expressions;

class program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Programa de mantenimiento para maquinaria");
        Console.ReadKey();
        Console.WriteLine();

        Console.WriteLine("Seleccione la máquina a inspeccionar");
        Console.WriteLine();
        Console.WriteLine("Menú de máquinas:");
        Console.WriteLine("1. Peletizadora");
        Console.WriteLine("2. Lavadora");
        Console.WriteLine("3. Pulverizadora");
        Console.WriteLine("1. Compactadora");  

        string opcion = Console.ReadLine();

        switch (opcion)
        {
            case "1":
                Console.WriteLine("Seleccionó la opción " + opcion + " Peletizadora");
                break;

            case "2":
                Console.WriteLine("Seleccionó la opción " + opcion + " Lavadora");
                break;

            case "3":
                Console.WriteLine("Seleccionó la opción " + opcion + " Pulverizadora");
                break;

            case "4":
                Console.WriteLine("Seleccionó la opción " + opcion + " Compactadora");
                break;

                default: Console.WriteLine("Seleccionó una opción invalida :(");
                break;

        }
  
        Console.ReadKey();
    }
}








