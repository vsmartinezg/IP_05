﻿using System.Timers;

class program
{
    static void Main(string[] args)
    {
        //EJERCICIO 1

        Console.WriteLine("Ejecicio 1: Operaciones aritméticas");
      
        double no1, no2, suma, resta, multi, division;

        Console.WriteLine("Ingrese un número:");
        no1 = double.Parse(Console.ReadLine());

        Console.WriteLine("Ingrese un segundo número:");
        no2 = double.Parse(Console.ReadLine());
        Console.WriteLine("");

        suma = no1 + no2;
        resta = no1 - no2;
        multi = no1 * no2;
        division = no1 / no2;

        Console.WriteLine(no1 + " + " + no2 + " = " + suma);
        Console.WriteLine(no1 + " - " + no2 + " = " + resta);
        Console.WriteLine(no1 + " * " + no2 + " = " + multi);
        Console.WriteLine(no1 + " / " + no2 + " = " + division);

        Console.WriteLine("");
        Console.WriteLine("Fin del ejercicio 1");
        Console.ReadKey();

        //EJERCICIO 2
        Console.WriteLine("");
        Console.WriteLine("Ejecicio 2: Operaciones booleanas");
        Console.WriteLine("");

        Console.WriteLine("Resultados del ejercicio anterior:");
        Console.WriteLine("Suma: " + suma);
        Console.WriteLine("Resta: " + resta);
        Console.WriteLine("Multiplicación: " + multi);
        Console.WriteLine("División: " + division);

        //if (suma >resta & suma>division & suma>multi)
        //{
        //    Console.WriteLine("El resultado de la suma es mayor a los demás: " + suma);
        //}
        //else
        //{
        //    Console.WriteLine("El resultado de la suma es menor a los demás: " + suma);
        //}

        //if (resta > suma & resta > division & resta > multi)
        //{
        //    Console.WriteLine("El resultado de la resta es mayor a los demás: " + resta);
        //}
        //else
        //{
        //    Console.WriteLine("El resultado de la resta es menor a los demás: " + resta);
        //}

        //if (division > resta & division > suma & division > multi)
        //{
        //    Console.WriteLine("El resultado de la división es mayor a los demás: " + division);
        //}
        //else
        //{
        //    Console.WriteLine("El resultado de la división es menor a los demás: " + division);
        //}

        //if (multi > resta & multi > division & multi > suma)
        //{
        //    Console.WriteLine("El resultado de la multiplicación es mayor a los demás: " + multi);
        //}
        //else
        //{
        //    Console.WriteLine("El resultado de la multiplicación es menor a los demás: " + multi);
        //}
        Console.WriteLine("No logré entender las instrucciones para este ejercicio");
        Console.WriteLine("");
        Console.WriteLine("Fin del ejercicio 2");
        Console.ReadKey();

        // EJERCICIO 3
        Console.WriteLine("");
        Console.WriteLine("Ejecicio 3");
        double a = 0.0;
        double b = 0.0;
        double c = 0.0;

        Console.WriteLine("Ingrese un número:");
        a = double.Parse(Console.ReadLine());

        Console.WriteLine("Ingrese un segundo número:");
        b = double.Parse(Console.ReadLine());

        Console.WriteLine("Ingrese un tercer número:");
        c = double.Parse(Console.ReadLine());
        Console.WriteLine("");

        double op1 = 0.0;
        double op2 = 0.0;
        double op3 = 0.0;
        double op4 = 0.0;

        op1 = a * b + c;
        op2 = a * (b + c);
        op3 = a / (b * c);
        op4 = (3 * a + 2 * b) / (Math.Pow(c, 2));

        Console.WriteLine("El resultado de la operación 1  a * b + c es: " + op1);
        Console.WriteLine("El resultado de la operación 2  a * (b + c) es: " + op2);
        Console.WriteLine("El resultado de la operación 3 a / (b * c) es: " + op3);
        Console.WriteLine("El resultado de la operación 4 (3 * a + 2 * b) / c^2 es: " + op4);

        Console.WriteLine("");
        Console.WriteLine("Fin del ejercicio 3");
        Console.ReadKey();

        //EJERCICIO 4
        //double reaizcubica = Math-Pow(9, 1/2);
        Console.WriteLine("");
        Console.WriteLine("Ejecicio 4: Expresión Cuadrática");

        Console.WriteLine("a = " + a);
        Console.WriteLine("b = " + b);
        Console.WriteLine("a = " + c);
        Console.WriteLine("");

        double x1, x2, bc, raiz;
        bc = b * b;
        raiz = bc - (4 * a * c);

        x1 = (-1*b) + raiz / 2*a;
        x2 = (-1 * b) - raiz / 2 * a;

        Console.WriteLine("-" + b + "± √" + bc + "-4(" + a + ")(" + c + ") / 2(" + a + ")");
        Console.WriteLine("El resultado 1 de la fórmula cuadrática es: " + x1);
        Console.WriteLine("El resultado 2 de la fórmula cuadrática es: " + x2);

        Console.WriteLine("");
        Console.WriteLine("Fin del ejercicio 4");
        Console.ReadKey();

    }
}
