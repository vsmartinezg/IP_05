﻿using System.ComponentModel;

class Program
{

    public static double dmonto;


    public static void Main(string[] args)
    {
        string smonto, scd;
        double dtotal, dtotalcd;

        Console.WriteLine("Laboratorio #9");
        Console.WriteLine();

        //Registro del monto:

        Console.WriteLine("Ingrese el monto total de la compra");
        smonto = Console.ReadLine();

        //Validación que el monto sea un número:

        while (!double.TryParse(smonto, out dmonto))
        {
            Console.WriteLine("Ingrese el monto como un número");
            smonto = Console.ReadLine();
        }

        Console.WriteLine("Monto guardado correctamente");

        //Validación si el monto aplica para los descuentos:

        if (dmonto < 400)
        {
            Console.WriteLine("Monto no aplica para descuentos :(");
            Console.WriteLine();

            Console.WriteLine("El total a pagar es: Q" + dmonto);
            Console.WriteLine();
            
            //Código de descuento:

            Console.WriteLine("¿Posee un código de descuento?");
            Console.WriteLine("Si lo posee, se agregará un 5% de descuento adicional al total");
            Console.WriteLine();

            Console.WriteLine("Escriba 1 para Si y 2 para No");
            scd = Console.ReadLine();

            if (scd == "1")
            {
                dtotalcd = dmonto - ((dmonto * 5) / 100);
                Console.WriteLine("El total a pagar con el código de descuento es: Q" + dtotalcd);
            }
            else if (scd == "2")
            {
                Console.WriteLine("El total a pagar se mantiene en : Q" + dmonto);

            }
            else
            {
                Console.WriteLine("ERROR: Ingrese 1 o 2");
            }

    }

        //El monto es mayor a 400:
        else
        {
            Console.WriteLine("Monto aplica para descuentos");
            Console.WriteLine();

            if (dmonto <= 1000)
            {
                Console.WriteLine("Su descuento es del 7%");
                Console.WriteLine();

                dtotal = dmonto - ((dmonto * 7) / 100);
                Console.WriteLine("El total a pagar es: Q" + dtotal);
                Console.WriteLine();


                //Código de descuento:

                Console.WriteLine("¿Posee un código de descuento?");
                Console.WriteLine("Si lo posee, se agregará un 5% de descuento adicional al total");
                Console.WriteLine();

                Console.WriteLine("Escriba 1 para Si y 2 para No");
                scd = Console.ReadLine();

                if (scd == "1")
                {
                    dtotalcd = dtotal - ((dtotal * 5) / 100);
                    Console.WriteLine("El total a pagar con el código de descuento es: Q" + dtotalcd);
                }
                else if (scd == "2")
                {
                    Console.WriteLine("El total a pagar se mantiene en : Q" + dtotal);

                }
                else
                {
                    Console.WriteLine("ERROR: Ingrese 1 o 2");
                }
            }



            else if (dmonto <= 5000)
            {
                Console.WriteLine("Su descuento es del 10% :)");
                Console.WriteLine();

                dtotal = dmonto - ((dmonto * 10) / 100);
                Console.WriteLine("El total a pagar es: Q" + dtotal);
                Console.WriteLine();


                    //Código de descuento:

                    Console.WriteLine("¿Posee un código de descuento?");
                    Console.WriteLine("Si lo posee, se agregará un 5% de descuento adicional al total");
                    Console.WriteLine();

                    Console.WriteLine("Escriba 1 para Si y 2 para No");
                    scd = Console.ReadLine();

                    if (scd == "1")
                    {
                        dtotalcd = dtotal - ((dtotal * 5) / 100);
                        Console.WriteLine("El total a pagar con el código de descuento es: Q" + dtotalcd);
                    }
                    else if (scd == "2")
                    {
                        Console.WriteLine("El total a pagar se mantiene en : Q" + dtotal);

                    }
                    else
                    {
                        Console.WriteLine("ERROR: Ingrese 1 o 2");
                    }
                }


            else if (dmonto <= 15000)
            {
                Console.WriteLine("Su descuento es del 15% :D");
                Console.WriteLine();

                dtotal = dmonto - ((dmonto * 15) / 100);
                Console.WriteLine("El total a pagar es: Q" + dtotal);
                Console.WriteLine();
            

                //Código de descuento:

                Console.WriteLine("¿Posee un código de descuento?");
                Console.WriteLine("Si lo posee, se agregará un 5% de descuento adicional al total");
                Console.WriteLine();

                Console.WriteLine("Escriba 1 para Si y 2 para No");
                scd = Console.ReadLine();

                if (scd == "1")
                {
                    dtotalcd = dtotal - ((dtotal * 5) / 100);
                    Console.WriteLine("El total a pagar con el código de descuento es: Q" + dtotalcd);
                }
                else if (scd == "2")
                {
                    Console.WriteLine("El total a pagar se mantiene en : Q" + dtotal);

                }
                else
                {
                    Console.WriteLine("ERROR: Ingrese 1 o 2");
                }
            }


            else if (dmonto > 15000)
            {
                Console.WriteLine("Su descuento es del 25% :O");
                Console.WriteLine();

                dtotal = dmonto - ((dmonto * 25) / 100);
                Console.WriteLine("El total a pagar es: Q" + dtotal);

                //Código de descuento:

                Console.WriteLine("¿Posee un código de descuento?");
                Console.WriteLine("Si lo posee, se agregará un 5% de descuento adicional al total");
                Console.WriteLine();

                Console.WriteLine("Escriba 1 para Si y 2 para No");
                scd = Console.ReadLine();

                if (scd == "1")
                {
                    dtotalcd = dtotal - ((dtotal * 5) / 100);
                    Console.WriteLine("El total a pagar con el código de descuento es: Q" + dtotalcd);
                }
                else if (scd == "2")
                {
                    Console.WriteLine("El total a pagar se mantiene en : Q" + dtotal);

                }
                else
                {
                    Console.WriteLine("ERROR: Ingrese 1 o 2");
                }
            }

           
            }
            }


            }

            
            
