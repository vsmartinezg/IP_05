﻿using System;
using System.Threading;
using System.Timers;

class program
{
    static void Main(string[] args)
    {
        //Problema 2

        double num;

        Console.WriteLine("Problema 2");
        Console.WriteLine("Vianna Martínez - 1166923");
        Console.WriteLine();

        //Definir el monto
        Console.WriteLine("Ingrese un monto entre 0 y 999.99:");
        Console.WriteLine("Recordatorio: El monto ingresado estará registrado en Quetzales");
        num = double.Parse(Console.ReadLine());

        //Validación de num dentro del rango
        if (num >= 0 & num <= 999.99)
        {
            int montoCentavos = (int)(num * 100);

            int billetes100 = montoCentavos / 10000;
            montoCentavos %= 10000;
            int billetes50 = montoCentavos / 5000;
            montoCentavos %= 5000;
            int billetes20 = montoCentavos / 2000;
            montoCentavos %= 2000;
            int billetes10 = montoCentavos / 1000;
            montoCentavos %= 1000;
            int billetes5 = montoCentavos / 500;
            montoCentavos %= 500;
            int monedas1 = montoCentavos / 100;
            montoCentavos %= 100;
            int monedas25 = montoCentavos / 25;
            montoCentavos %= 25;
            int monedas1centavo = montoCentavos;

            Console.WriteLine();
            Console.WriteLine("El monto ingresado puede ser dividido de la siguiente manera:");

            Console.WriteLine($"Billetes de Q100: {billetes100}");
            Console.WriteLine($"Billetes de Q50: {billetes50}");
            Console.WriteLine($"Billetes de Q20: {billetes20}");
            Console.WriteLine($"Billetes de Q10: {billetes10}");
            Console.WriteLine($"Billetes de Q5: {billetes5}");
            Console.WriteLine($"Monedas de Q1: {monedas1}");
            Console.WriteLine($"Monedas de Q0.25: {monedas25}");
            Console.WriteLine($"Monedas de Q0.01: {monedas1centavo}");

            Console.WriteLine();
            Console.WriteLine("Gacias por venir! :D");
        } 

        else
        {
            Console.WriteLine("ERROR: Ingrese un número entre 0 y 999.99");
        }
        Console.ReadKey();
    }
}
