﻿class Program
{
    static void Main(string[] arg)
    {
        //Registro de datos del usuario
        string sNombre, sEdad, sCarrera, sCarne;
        Console.WriteLine("Ingresa tu nomnbre");
        sNombre = Console.ReadLine();

        Console.WriteLine("Ingresa tu edad");
        sEdad = Console.ReadLine();

        Console.WriteLine("Ingresa tu Carrera");
        sCarrera = Console.ReadLine();

        Console.WriteLine("Ingresa tu número de carné");
        sCarne = Console.ReadLine();
        Console.WriteLine();

        //Introducción

        Console.WriteLine("Mi segundo programa");
        Console.WriteLine();

        //Mostrar los datos
        Console.WriteLine("Nombre: " + sNombre);
        Console.WriteLine("Edad: " + sEdad);
        Console.WriteLine("Carrera: " + sCarrera);
        Console.WriteLine("Carné: " + sCarne);
        Console.ReadKey();

        Console.WriteLine();
        Console.Write("Soy " + sNombre + ", tengo " + sEdad + " años y estudio la carrera de " + sCarrera + ".");
        Console.WriteLine();
        Console.WriteLine("Mi número de carné es " + sCarne) ;
    }
}