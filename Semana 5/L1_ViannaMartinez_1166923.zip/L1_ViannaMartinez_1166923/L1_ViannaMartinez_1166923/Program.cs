﻿
class Program
{
    static void Main(string[] arg)
    {
        Console.WriteLine("Ingrese su nombre, por favor");
        string Nombre = Console.ReadLine();

        //Por estética se dio la instrucción writeline de nuevo, sin texto, para dejar un espacio sin tener que pulsar una tecla para continuar.
        Console.WriteLine();

        Console.WriteLine("Hola Mundo");
        Console.WriteLine("Soy " + Nombre + " :D");

        //Por estética se dio la instrucción writeline de nuevo, sin texto, para dejar un espacio sin tener que pulsar una tecla pra continuar.
        Console.WriteLine();

        /*La instrucción Write escribe el texto seguido (en la misma línea) mientras que WriteLine escribe cada instrucción en una linea diferente*/

        Console.Write("Hola Mundo, ");
        Console.Write("soy " + Nombre + " :D");
        Console.ReadKey();
    }
}