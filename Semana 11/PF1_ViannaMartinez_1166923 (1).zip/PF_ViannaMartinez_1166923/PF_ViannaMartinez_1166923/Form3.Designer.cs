﻿namespace PF_ViannaMartinez_1166923
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label3 = new Label();
            button1 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Wide Latin", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(157, 69);
            label1.Name = "label1";
            label1.Size = new Size(456, 34);
            label1.TabIndex = 0;
            label1.Text = "Menú de Máquinas";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Yu Gothic UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label3.ForeColor = Color.White;
            label3.Location = new Point(12, 9);
            label3.Name = "label3";
            label3.Size = new Size(161, 28);
            label3.TabIndex = 7;
            label3.Text = "Proceso Principal";
            // 
            // button1
            // 
            button1.BackColor = Color.DarkOrchid;
            button1.Location = new Point(12, 494);
            button1.Name = "button1";
            button1.Size = new Size(139, 60);
            button1.TabIndex = 8;
            button1.Text = "Menú Principal";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.wallper8;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(771, 566);
            Controls.Add(button1);
            Controls.Add(label3);
            Controls.Add(label1);
            ForeColor = SystemColors.Control;
            Name = "Form3";
            Text = "Proceso Principal";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label3;
        private Button button1;
    }
}