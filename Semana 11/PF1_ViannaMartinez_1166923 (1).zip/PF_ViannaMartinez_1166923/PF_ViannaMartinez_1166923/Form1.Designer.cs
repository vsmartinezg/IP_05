﻿namespace PF_ViannaMartinez_1166923
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            richTextBox1 = new RichTextBox();
            button1 = new Button();
            label2 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Wide Latin", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            label1.ForeColor = Color.White;
            label1.Location = new Point(190, 28);
            label1.Margin = new Padding(5, 0, 5, 0);
            label1.Name = "label1";
            label1.Size = new Size(447, 42);
            label1.TabIndex = 0;
            label1.Text = "Proyecto Final";
            // 
            // richTextBox1
            // 
            richTextBox1.Enabled = false;
            richTextBox1.HideSelection = false;
            richTextBox1.Location = new Point(102, 193);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.Size = new Size(622, 104);
            richTextBox1.TabIndex = 2;
            richTextBox1.Text = "Este programa permite chequear el estado de 4 máquinas de la recicladora de plástico. Así mismo determinar si estas necesitan mantenimiento para prevenir fallos.";
            //richTextBox1.TextChanged += richTextBox1_TextChanged;
            // 
            // button1
            // 
            button1.BackColor = Color.Plum;
            button1.Location = new Point(650, 417);
            button1.Name = "button1";
            button1.Size = new Size(133, 54);
            button1.TabIndex = 3;
            button1.Text = "Continuar";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Wide Latin", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label2.ForeColor = Color.White;
            label2.Location = new Point(43, 90);
            label2.Margin = new Padding(5, 0, 5, 0);
            label2.Name = "label2";
            label2.Size = new Size(740, 68);
            label2.TabIndex = 4;
            label2.Text = "Monitoreo de Máquinas en una \r\n       Recicladora de Plástico";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(13F, 31F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.wallper8;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(827, 502);
            Controls.Add(label2);
            Controls.Add(button1);
            Controls.Add(richTextBox1);
            Controls.Add(label1);
            Font = new Font("Yu Gothic UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            Margin = new Padding(5);
            Name = "Form1";
            Text = "Título Inicial";
            TopMost = true;
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private RichTextBox richTextBox1;
        private Button button1;
        private Label label2;
    }
}